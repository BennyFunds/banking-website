/* =========================================================
   NEXABANK - FRONT-END DEMO BANKING APPLICATION
   ---------------------------------------------------------
   Sections:
   1.  Config & constants
   2.  DOM references
   3.  Application state
   4.  Storage layer
   5.  Utilities
   6.  Toast notifications
   7.  Public site navigation (mobile menu, home link)
   8.  Modals
   9.  Password visibility toggles
   10. Authentication (sign up, log in, log out, restore)
   11. Dashboard rendering
   12. Transactions
   13. Transfers
   14. Dashboard UI (sidebar, balance eyes, view all)
   15. Init

   NOTE: This is a front-end demo only. Real authentication,
   balances and transfers must be handled by a server.
========================================================= */

(() => {
    "use strict";


    /* =====================================================
       1. CONFIG & CONSTANTS
    ===================================================== */

    const STORAGE_KEYS = {
        users: "nexaBankUsers",
        session: "nexaBankSession",
        legacySession: "nexaBankCurrentUser" // old key stored full user + password
    };

    const TOAST_DURATION_MS = 4000;
    const MAX_TRANSACTIONS = 30;
    const MIN_PASSWORD_LENGTH = 6;
    const HIDDEN_BALANCE_TEXT = "••••••••";

    /* Demo account (visible to anyone reading this file) */
    const DEMO_ACCOUNT = {
        id: "flair1234",
        name: "Flair1234",
        username: "Flair1234",
        email: "Flair1234",
        password: "Debby1234",
        checkingBalance: 500000,
        savingsBalance: 0
    };

    /* Starting data for newly created accounts */
    const NEW_ACCOUNT_CHECKING = 12840.5;
    const NEW_ACCOUNT_SAVINGS = 5420;

    const DEFAULT_TRANSACTIONS = [
        { description: "Salary Deposit",   date: "Aug 28, 2026", amount: 4200,    type: "income",  status: "Completed" },
        { description: "Grocery Market",   date: "Aug 27, 2026", amount: -86.42,  type: "expense", status: "Completed" },
        { description: "Electricity Bill", date: "Aug 25, 2026", amount: -145,    type: "expense", status: "Completed" },
        { description: "Online Transfer",  date: "Aug 23, 2026", amount: -250,    type: "expense", status: "Completed" },
        { description: "Coffee Shop",      date: "Aug 21, 2026", amount: -12.5,   type: "expense", status: "Completed" }
    ];


    /* =====================================================
       2. DOM REFERENCES
    ===================================================== */

    const $ = id => document.getElementById(id);

    const homeView = $("homeView");
    const dashboardView = $("dashboardView");

    const modalOverlay = $("modalOverlay");
    const loginModal = $("loginModal");
    const signupModal = $("signupModal");

    const loginForm = $("loginForm");
    const signupForm = $("signupForm");
    const transferForm = $("transferForm");

    const loginMessage = $("loginMessage");
    const signupMessage = $("signupMessage");
    const transferMessage = $("transferMessage");

    const transactionsList = $("transactionsList");
    const dashboardContent = document.querySelector(".dashboard-content");

    const mobileMenuBtn = $("mobileMenuBtn");
    const navMenu = $("navMenu");

    const logoutBtn = $("logoutBtn");

    const dashboardSidebar = $("dashboardSidebar");
    const dashboardMobileMenu = $("dashboardMobileMenu");

    const toast = $("toast");
    const toastTitle = $("toastTitle");
    const toastMessage = $("toastMessage");
    const toastClose = $("toastClose");


    /* =====================================================
       3. APPLICATION STATE
    ===================================================== */

    let currentUser = null;
    let toastTimeout = null;

    /* Which balances are currently masked */
    const hiddenBalances = {
        checking: false,
        savings: false
    };


    /* =====================================================
       4. STORAGE LAYER
    ===================================================== */

    function getStoredUsers() {
        try {
            const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.users));
            return Array.isArray(users) ? users : [];
        } catch (error) {
            console.error("Unable to read users:", error);
            return [];
        }
    }

    function saveStoredUsers(users) {
        try {
            localStorage.setItem(STORAGE_KEYS.users, JSON.stringify(users));
        } catch (error) {
            console.error("Unable to save users:", error);
        }
    }

    /* Replace (or insert) a single user in storage */
    function persistUser(user) {
        const users = getStoredUsers();
        const index = users.findIndex(item => item.id === user.id);

        if (index === -1) {
            users.push(user);
        } else {
            users[index] = user;
        }

        saveStoredUsers(users);
    }

    /* The session stores ONLY the user id - never balances or passwords */
    function getSessionUserId() {
        try {
            return localStorage.getItem(STORAGE_KEYS.session);
        } catch (error) {
            return null;
        }
    }

    function saveSession(userId) {
        try {
            localStorage.setItem(STORAGE_KEYS.session, userId);
        } catch (error) {
            console.error("Unable to save session:", error);
        }
    }

    function clearSession() {
        try {
            localStorage.removeItem(STORAGE_KEYS.session);
            localStorage.removeItem(STORAGE_KEYS.legacySession);
        } catch (error) {
            console.error("Unable to clear session:", error);
        }
    }


    /* =====================================================
       5. UTILITIES
    ===================================================== */

    const currencyFormatter = new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD"
    });

    function formatCurrency(value) {
        return currencyFormatter.format(value);
    }

    /* Avoid floating-point drift (e.g. 0.1 + 0.2) */
    function roundToCents(value) {
        return Math.round((value + Number.EPSILON) * 100) / 100;
    }

    function getInitials(name) {
        if (!name) return "U";

        return name
            .split(" ")
            .filter(Boolean)
            .slice(0, 2)
            .map(part => part.charAt(0).toUpperCase())
            .join("");
    }

    function getFirstName(name) {
        if (!name) return "User";
        return name.trim().split(" ")[0];
    }

    /* "Saturday, October 24" - used in the dashboard header */
    function getTodayLong() {
        return new Intl.DateTimeFormat("en-US", {
            weekday: "long",
            month: "long",
            day: "numeric"
        }).format(new Date());
    }

    /* "Oct 24, 2026" - used on transactions (matches seeded data) */
    function getTodayShort() {
        return new Intl.DateTimeFormat("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric"
        }).format(new Date());
    }

    function escapeHTML(value) {
        const div = document.createElement("div");
        div.textContent = value;
        return div.innerHTML;
    }

    function showMessage(element, message, type = "error") {
        element.textContent = message;
        element.className = `form-message ${type}`;
    }

    function clearMessage(element) {
        element.textContent = "";
        element.className = "form-message";
    }

    /* SHA-256 hash so passwords aren't stored in plain text.
       Still demo-grade: real apps hash on the server with a salt. */
    async function hashPassword(password) {
        if (!window.crypto || !window.crypto.subtle) {
            return `plain:${password}`; // fallback for non-secure contexts
        }

        const bytes = new TextEncoder().encode(password);
        const digest = await window.crypto.subtle.digest("SHA-256", bytes);

        return Array.from(new Uint8Array(digest))
            .map(byte => byte.toString(16).padStart(2, "0"))
            .join("");
    }

    function createStartingTransactions() {
        return DEFAULT_TRANSACTIONS.map(transaction => ({ ...transaction }));
    }


    /* =====================================================
       6. TOAST NOTIFICATIONS
    ===================================================== */

    function showToast(title, message) {
        clearTimeout(toastTimeout);

        toastTitle.textContent = title;
        toastMessage.textContent = message;
        toast.classList.add("active");

        toastTimeout = setTimeout(() => {
            toast.classList.remove("active");
        }, TOAST_DURATION_MS);
    }

    toastClose.addEventListener("click", () => {
        clearTimeout(toastTimeout);
        toast.classList.remove("active");
    });


    /* =====================================================
       7. PUBLIC SITE NAVIGATION
    ===================================================== */

    function setMobileMenu(open) {
        navMenu.classList.toggle("active", open);
        mobileMenuBtn.setAttribute("aria-expanded", String(open));
        mobileMenuBtn.innerHTML = open
            ? '<i class="fa-solid fa-xmark"></i>'
            : '<i class="fa-solid fa-bars"></i>';
    }

    mobileMenuBtn.addEventListener("click", () => {
        setMobileMenu(!navMenu.classList.contains("active"));
    });

    document.querySelectorAll(".nav-link").forEach(link => {
        link.addEventListener("click", () => setMobileMenu(false));
    });

    /* Logo / "home" links. Logs the user out if one is signed in. */
    document.querySelectorAll('[data-view="home"]').forEach(link => {
        link.addEventListener("click", event => {
            event.preventDefault();

            if (currentUser) {
                currentUser = null;
                clearSession();
            }

            showHome();
        });
    });


    /* =====================================================
       8. MODALS
    ===================================================== */

    function openModal(type) {
        modalOverlay.classList.add("active");
        document.body.classList.add("modal-open");

        loginModal.classList.remove("active");
        signupModal.classList.remove("active");

        clearMessage(loginMessage);
        clearMessage(signupMessage);

        if (type === "login") {
            loginModal.classList.add("active");
            setTimeout(() => $("loginUsername")?.focus(), 50);
        }

        if (type === "signup") {
            signupModal.classList.add("active");
            setTimeout(() => $("signupName")?.focus(), 50);
        }
    }

    function closeModal() {
        modalOverlay.classList.remove("active");
        document.body.classList.remove("modal-open");

        loginModal.classList.remove("active");
        signupModal.classList.remove("active");

        clearMessage(loginMessage);
        clearMessage(signupMessage);
    }

    document.querySelectorAll(".login-trigger").forEach(button => {
        button.addEventListener("click", () => openModal("login"));
    });

    document
        .querySelectorAll(".open-account-trigger, .nav-open-account")
        .forEach(button => {
            button.addEventListener("click", () => openModal("signup"));
        });

    document.querySelectorAll("[data-close-modal]").forEach(button => {
        button.addEventListener("click", closeModal);
    });

    document.querySelectorAll(".switch-modal").forEach(button => {
        button.addEventListener("click", () => openModal(button.dataset.switch));
    });

    /* Click on the backdrop closes the modal */
    modalOverlay.addEventListener("click", event => {
        if (event.target === modalOverlay) closeModal();
    });

    /* Escape closes modal and mobile sidebar */
    document.addEventListener("keydown", event => {
        if (event.key !== "Escape") return;

        if (modalOverlay.classList.contains("active")) closeModal();
        dashboardSidebar.classList.remove("active");
    });


    /* =====================================================
       9. PASSWORD VISIBILITY TOGGLES
    ===================================================== */

    document.querySelectorAll(".password-toggle").forEach(button => {
        button.addEventListener("click", () => {
            const input = $(button.dataset.target);
            if (!input) return;

            const icon = button.querySelector("i");
            const showing = input.type === "text";

            input.type = showing ? "password" : "text";
            icon.className = showing ? "fa-regular fa-eye" : "fa-regular fa-eye-slash";
            button.setAttribute("aria-label", showing ? "Show password" : "Hide password");
        });
    });


    /* =====================================================
       10. AUTHENTICATION
    ===================================================== */

    /* Make sure the demo account exists in storage so that
       sessions restore and transfers persist for it. */
    async function ensureDemoAccount() {
        const users = getStoredUsers();

        if (users.some(user => user.id === DEMO_ACCOUNT.id)) return;

        const { password, ...rest } = DEMO_ACCOUNT;

        users.push({
            ...rest,
            passwordHash: await hashPassword(password),
            transactions: [
                {
                    description: "Opening Balance",
                    date: getTodayShort(),
                    amount: DEMO_ACCOUNT.checkingBalance,
                    type: "income",
                    status: "Completed"
                }
            ]
        });

        saveStoredUsers(users);
    }

    /* ---------- Sign up ---------- */

    signupForm.addEventListener("submit", async event => {
        event.preventDefault();
        clearMessage(signupMessage);

        const name = $("signupName").value.trim();
        const email = $("signupEmail").value.trim().toLowerCase();
        const password = $("signupPassword").value;

        if (name.length < 2) {
            showMessage(signupMessage, "Please enter your full name.");
            return;
        }

        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            showMessage(signupMessage, "Please enter a valid email address.");
            return;
        }

        if (password.length < MIN_PASSWORD_LENGTH) {
            showMessage(
                signupMessage,
                `Password must contain at least ${MIN_PASSWORD_LENGTH} characters.`
            );
            return;
        }

        const users = getStoredUsers();

        if (users.some(user => user.email === email)) {
            showMessage(signupMessage, "An account with this email already exists.");
            return;
        }

        users.push({
            id: `user-${Date.now()}`,
            name,
            username: email,
            email,
            passwordHash: await hashPassword(password),
            checkingBalance: NEW_ACCOUNT_CHECKING,
            savingsBalance: NEW_ACCOUNT_SAVINGS,
            transactions: createStartingTransactions()
        });

        saveStoredUsers(users);

        showMessage(signupMessage, "Account created successfully!", "success");

        setTimeout(() => {
            signupForm.reset();
            openModal("login");

            $("loginUsername").value = email;

            showMessage(
                loginMessage,
                "Your account is ready. Please log in.",
                "success"
            );
        }, 900);
    });

    /* ---------- Log in ---------- */

    loginForm.addEventListener("submit", async event => {
        event.preventDefault();
        clearMessage(loginMessage);

        const identifier = $("loginUsername").value.trim();
        const password = $("loginPassword").value;

        if (!identifier || !password) {
            showMessage(loginMessage, "Please enter your username and password.");
            return;
        }

        const lookup = identifier.toLowerCase();
        const passwordHash = await hashPassword(password);

        const user = getStoredUsers().find(item =>
            (item.username || "").toLowerCase() === lookup ||
            (item.email || "").toLowerCase() === lookup
        );

        /* Same message for unknown user and wrong password */
        if (!user || user.passwordHash !== passwordHash) {
            showMessage(loginMessage, "Incorrect username or password.");
            return;
        }

        currentUser = user;
        saveSession(user.id);

        closeModal();
        loginForm.reset();
        showDashboard();

        showToast("Welcome back", `Good to see you, ${getFirstName(user.name)}.`);
    });

    /* ---------- Log out ---------- */

    logoutBtn.addEventListener("click", () => {
        currentUser = null;
        clearSession();

        showHome();

        showToast("Logged out", "You have been safely logged out.");
    });

    /* ---------- Restore session on page load ---------- */

    function restoreSession() {
        /* Remove the old session format (it contained the password) */
        try {
            localStorage.removeItem(STORAGE_KEYS.legacySession);
        } catch (error) { /* ignore */ }

        const userId = getSessionUserId();
        if (!userId) return;

        const storedUser = getStoredUsers().find(user => user.id === userId);

        if (storedUser) {
            currentUser = storedUser;
            showDashboard();
        } else {
            clearSession();
        }
    }


    /* =====================================================
       11. DASHBOARD RENDERING
    ===================================================== */

    function showDashboard() {
        homeView.classList.remove("active");
        dashboardView.classList.add("active");

        updateDashboard();

        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    function showHome() {
        dashboardView.classList.remove("active");
        homeView.classList.add("active");

        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    function updateDashboard() {
        if (!currentUser) return;

        const initials = getInitials(currentUser.name);

        $("dashboardUserName").textContent = getFirstName(currentUser.name);
        $("sidebarUserName").textContent = currentUser.name;

        $("dashboardAvatar").textContent = initials;
        $("sidebarAvatar").textContent = initials;

        $("dashboardDate").textContent = getTodayLong();

        renderBalances();
        renderTransactions();
    }

    /* Balances are always rendered from state, so the hide/show
       toggle can never get out of sync after a transfer. */
    function renderBalances() {
        if (!currentUser) return;

        const balances = {
            checking: { elementId: "checkingBalance", value: currentUser.checkingBalance },
            savings:  { elementId: "savingsBalance",  value: currentUser.savingsBalance }
        };

        Object.entries(balances).forEach(([type, { elementId, value }]) => {
            const element = $(elementId);
            const hidden = hiddenBalances[type];

            element.textContent = hidden ? HIDDEN_BALANCE_TEXT : formatCurrency(value);
            element.dataset.hidden = String(hidden);

            const icon = document.querySelector(`.balance-eye[data-balance="${type}"] i`);
            if (icon) {
                icon.className = hidden ? "fa-regular fa-eye-slash" : "fa-regular fa-eye";
            }
        });
    }


    /* =====================================================
       12. TRANSACTIONS
    ===================================================== */

    function renderTransactions() {
        if (!currentUser) return;

        transactionsList.innerHTML = "";

        const transactions = currentUser.transactions || [];

        if (transactions.length === 0) {
            transactionsList.innerHTML = `
                <div class="empty-transactions">No transactions yet.</div>
            `;
            return;
        }

        transactions.forEach(transaction => {
            const isIncome = transaction.type === "income";

            const amount = isIncome
                ? `+${formatCurrency(transaction.amount)}`
                : formatCurrency(transaction.amount);

            const row = document.createElement("div");
            row.className = "transaction-row";

            row.innerHTML = `
                <div class="transaction-info">
                    <div class="transaction-icon ${isIncome ? "income" : ""}">
                        <i class="fa-solid ${isIncome ? "fa-arrow-down" : "fa-arrow-up"}"></i>
                    </div>
                    <div>
                        <strong>${escapeHTML(transaction.description)}</strong>
                        <span>${isIncome ? "Money received" : "Payment"}</span>
                    </div>
                </div>

                <div class="transaction-date">${escapeHTML(transaction.date)}</div>

                <div class="transaction-amount ${isIncome ? "income" : ""}">${amount}</div>

                <div class="transaction-status">${escapeHTML(transaction.status)}</div>
            `;

            transactionsList.appendChild(row);
        });
    }


    /* =====================================================
       13. TRANSFERS & RECEIPTS
    ===================================================== */

    const TRANSFER_TYPES = {
        ach:  { label: "ACH transfer",  fee: 0,  eta: "1–3 business days" },
        wire: { label: "Domestic wire", fee: 25, eta: "Same business day if sent before 4:00 PM ET" }
    };
    const FROM_ACCOUNT_LABEL = "Checking •••• 2847";

    const esc = value => escapeHTML(String(value ?? "")).replace(/"/g, "&quot;");

    /* ABA routing number checksum */
    function isValidRoutingNumber(value) {
        if (!/^\d{9}$/.test(value)) return false;
        const d = value.split("").map(Number);
        return (3 * (d[0] + d[3] + d[6]) + 7 * (d[1] + d[4] + d[7]) + (d[2] + d[5] + d[8])) % 10 === 0;
    }

    function generateConfirmationNumber() {
        const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
        return `NXB-${Date.now().toString(36).toUpperCase()}-${rand}`;
    }

    function buildTransferForm() {
        transferForm.className = "transfer-form transfer-form-full";
        transferForm.innerHTML = `
            <div class="form-group">
                <label for="transferType">Transfer type</label>
                <div class="input-wrapper plain"><select id="transferType">
                    <option value="ach">ACH transfer – free, 1–3 business days</option>
                    <option value="wire">Domestic wire – $25 fee, same day</option>
                </select></div>
            </div>
            <div class="form-group">
                <label for="recipient">Recipient full name</label>
                <div class="input-wrapper plain"><input type="text" id="recipient" placeholder="Name on the account" autocomplete="off" required></div>
            </div>
            <div class="form-group">
                <label for="routingNumber">Routing number (ABA)</label>
                <div class="input-wrapper plain"><input type="text" id="routingNumber" inputmode="numeric" maxlength="9" placeholder="9 digits" autocomplete="off" required></div>
            </div>
            <div class="form-group">
                <label for="accountNumber">Account number</label>
                <div class="input-wrapper plain"><input type="text" id="accountNumber" inputmode="numeric" maxlength="17" placeholder="4–17 digits" autocomplete="off" required></div>
            </div>
            <div class="form-group">
                <label for="recipientAccountType">Recipient account type</label>
                <div class="input-wrapper plain"><select id="recipientAccountType">
                    <option value="Checking">Checking</option>
                    <option value="Savings">Savings</option>
                </select></div>
            </div>
            <div class="form-group">
                <label for="transferAmount">Amount (USD)</label>
                <div class="input-wrapper">
                    <span class="currency-symbol">$</span>
                    <input type="number" id="transferAmount" placeholder="0.00" min="0.01" step="0.01" required>
                </div>
            </div>
            <div class="form-group span-2">
                <label for="transferMemo">Memo (optional)</label>
                <div class="input-wrapper plain"><input type="text" id="transferMemo" maxlength="60" placeholder="e.g. Rent for November"></div>
            </div>
            <label class="checkbox-label span-2">
                <input type="checkbox" id="transferAuthorize">
                <span></span>
                I authorize NexaBank to send this transfer and confirm the details above are correct.
            </label>
            <button type="submit" class="btn btn-primary transfer-btn span-2">
                Send money <i class="fa-solid fa-arrow-right"></i>
            </button>`;
    }

    transferForm.addEventListener("submit", event => {
        event.preventDefault();
        clearMessage(transferMessage);

        if (!currentUser) {
            showMessage(transferMessage, "Please log in to make a transfer.");
            return;
        }

        const type = TRANSFER_TYPES[$("transferType").value] || TRANSFER_TYPES.ach;
        const recipient = $("recipient").value.trim();
        const routing = $("routingNumber").value.replace(/\s/g, "");
        const accountNumber = $("accountNumber").value.replace(/\s/g, "");
        const accountType = $("recipientAccountType").value;
        const memo = $("transferMemo").value.trim();
        const amount = roundToCents(Number($("transferAmount").value));

        if (recipient.length < 2) return showMessage(transferMessage, "Enter the recipient's full name.");
        if (!isValidRoutingNumber(routing)) return showMessage(transferMessage, "Enter a valid 9-digit routing number.");
        if (!/^\d{4,17}$/.test(accountNumber)) return showMessage(transferMessage, "Account number must be 4–17 digits.");
        if (!Number.isFinite(amount) || amount < 0.01) return showMessage(transferMessage, "Please enter a valid amount.");

        const total = roundToCents(amount + type.fee);

        if (total > currentUser.checkingBalance) {
            return showMessage(transferMessage, "Insufficient funds (the amount plus any fee exceeds your available balance).");
        }
        if (!$("transferAuthorize").checked) {
            return showMessage(transferMessage, "Please authorize the transfer to continue.");
        }

        const receipt = {
            id: generateConfirmationNumber(),
            createdAt: new Date().toISOString(),
            typeLabel: type.label,
            status: "Processing",
            fromLabel: FROM_ACCOUNT_LABEL,
            senderName: currentUser.name,
            recipient,
            routing,
            accountLast4: accountNumber.slice(-4),
            accountType,
            amount,
            fee: type.fee,
            total,
            eta: type.eta,
            memo
        };

        currentUser.checkingBalance = roundToCents(currentUser.checkingBalance - total);

        if (!Array.isArray(currentUser.transactions)) currentUser.transactions = [];

        currentUser.transactions.unshift({
            description: `${type.label} to ${recipient}`,
            date: getTodayShort(),
            amount: -total,
            type: "expense",
            status: "Processing",
            receipt
        });
        currentUser.transactions = currentUser.transactions.slice(0, MAX_TRANSACTIONS);

        persistUser(currentUser);
        transferForm.reset();
        updateDashboard();
        showReceipt(receipt);
    });

    /* ---------- Receipt ---------- */

    let receiptOverlay = null;

    function showReceipt(r) {
        if (!receiptOverlay) {
            receiptOverlay = document.createElement("div");
            receiptOverlay.id = "receiptOverlay";
            receiptOverlay.className = "modal-overlay";
            document.body.appendChild(receiptOverlay);

            receiptOverlay.addEventListener("click", e => {
                if (e.target === receiptOverlay || e.target.closest("[data-receipt-close]")) closeReceipt();
                else if (e.target.closest("[data-receipt-print]")) window.print();
            });
        }

        const when = new Intl.DateTimeFormat("en-US", {
            dateStyle: "medium", timeStyle: "short", timeZoneName: "short"
        }).format(new Date(r.createdAt));

        const row = (label, value) => `<div class="receipt-row"><span>${label}</span><strong>${value}</strong></div>`;

        receiptOverlay.innerHTML = `
            <div class="modal receipt active" role="dialog" aria-modal="true" aria-label="Transfer receipt">
                <button class="modal-close" data-receipt-close aria-label="Close"><i class="fa-solid fa-xmark"></i></button>
                <div class="receipt-head">
                    <div class="modal-icon signup-icon"><i class="fa-solid fa-circle-check"></i></div>
                    <h2>Transfer submitted</h2>
                    <p class="receipt-amount">${formatCurrency(r.amount)}</p>
                    <span class="transaction-status">${esc(r.status)}</span>
                </div>
                <div class="receipt-body">
                    ${row("Confirmation no.", esc(r.id))}
                    ${row("Date &amp; time", esc(when))}
                    ${row("Transfer type", esc(r.typeLabel))}
                    ${row("From", `${esc(r.senderName)} · ${esc(r.fromLabel)}`)}
                    ${row("To", esc(r.recipient))}
                    ${row("Recipient account", `${esc(r.accountType)} •••• ${esc(r.accountLast4)}`)}
                    ${row("Routing number", esc(r.routing))}
                    ${r.memo ? row("Memo", esc(r.memo)) : ""}
                    ${row("Estimated arrival", esc(r.eta))}
                    ${row("Amount", formatCurrency(r.amount))}
                    ${row("Fee", formatCurrency(r.fee))}
                    <div class="receipt-row receipt-total"><span>Total debited</span><strong>${formatCurrency(r.total)}</strong></div>
                </div>
                <p class="receipt-note">Keep this receipt for your records. Contact support promptly if you did not authorize this transfer.</p>
                <div class="receipt-actions">
                    <button class="btn btn-outline" data-receipt-print><i class="fa-solid fa-print"></i> Print / Save PDF</button>
                    <button class="btn btn-primary" data-receipt-close>Done</button>
                </div>
            </div>`;

        receiptOverlay.classList.add("active");
        document.body.classList.add("modal-open");
    }

    function closeReceipt() {
        if (!receiptOverlay) return;
        receiptOverlay.classList.remove("active");
        document.body.classList.remove("modal-open");
    }

    document.addEventListener("keydown", event => {
        if (event.key === "Escape") closeReceipt();
    });

    /* Click a past transaction to reopen its receipt */
    transactionsList.addEventListener("click", event => {
        const row = event.target.closest(".transaction-row");
        if (!row || !currentUser) return;

        const index = Array.from(transactionsList.children).indexOf(row);
        const receipt = currentUser.transactions[index]?.receipt;
        if (receipt) showReceipt(receipt);
    });


    /* =====================================================
       13b. DASHBOARD PANELS (Cards, Insights, Settings)
    ===================================================== */

    const PANEL_ORDER = ["overview", "transfers", "cards", "insights", "settings"];

    const DEFAULT_SETTINGS = {
        twoStep: false, biometric: false,
        alertTransactions: true, alertLowBalance: true, alertSecurity: true,
        channelEmail: true, channelSms: false, channelPush: true,
        paperless: true, marketing: false,
        profile: { phone: "", street: "", city: "", state: "", zip: "" }
    };

    let overviewNodes = [];
    let panelEl = null;

    function getSettings() {
        const saved = currentUser?.settings || {};
        return { ...DEFAULT_SETTINGS, ...saved, profile: { ...DEFAULT_SETTINGS.profile, ...(saved.profile || {}) } };
    }

    function comingSoonHTML(icon, title, text) {
        return `<div class="coming-soon">
            <div class="coming-soon-icon"><i class="fa-solid ${icon}"></i></div>
            <span class="section-label">COMING SOON</span>
            <h2>${title}</h2>
            <p>${text}</p>
        </div>`;
    }

    function toggleRow(key, label, description, checked) {
        return `<label class="setting-row">
            <span><strong>${label}</strong><small>${description}</small></span>
            <span class="switch"><input type="checkbox" data-setting="${key}" ${checked ? "checked" : ""}><i></i></span>
        </label>`;
    }

    function field(id, label, value = "", extra = "") {
        return `<div class="form-group"><label for="${id}">${label}</label>
            <div class="input-wrapper plain"><input id="${id}" value="${esc(value)}" ${extra}></div></div>`;
    }

    function settingsHTML() {
        const s = getSettings(), p = s.profile;

        return `
        <div class="dashboard-section-header"><div><span class="section-label">ACCOUNT</span><h2>Settings</h2></div></div>
        <div class="settings-grid">
            <section class="settings-card">
                <h3>Profile &amp; contact</h3>
                <form id="profileForm" novalidate>
                    ${field("setName", "Full name", currentUser.name, 'autocomplete="name"')}
                    ${field("setEmail", "Email / username", currentUser.email || "", "readonly")}
                    ${field("setPhone", "Mobile phone", p.phone, 'inputmode="tel" placeholder="(555) 555-5555" autocomplete="tel"')}
                    ${field("setStreet", "Mailing address", p.street, 'autocomplete="address-line1"')}
                    ${field("setCity", "City", p.city, 'autocomplete="address-level2"')}
                    <div class="settings-two">
                        ${field("setState", "State", p.state, 'maxlength="2" placeholder="NY" autocomplete="address-level1"')}
                        ${field("setZip", "ZIP code", p.zip, 'inputmode="numeric" maxlength="10" autocomplete="postal-code"')}
                    </div>
                    <button class="btn btn-primary" type="submit">Save changes</button>
                    <div class="form-message" role="alert"></div>
                </form>
            </section>

            <section class="settings-card">
                <h3>Security</h3>
                <form id="passwordForm" novalidate>
                    <div class="form-group"><label for="curPw">Current password</label><div class="input-wrapper plain"><input id="curPw" type="password" autocomplete="current-password"></div></div>
                    <div class="form-group"><label for="newPw">New password</label><div class="input-wrapper plain"><input id="newPw" type="password" autocomplete="new-password"></div><small class="input-help">At least 8 characters.</small></div>
                    <div class="form-group"><label for="newPw2">Confirm new password</label><div class="input-wrapper plain"><input id="newPw2" type="password" autocomplete="new-password"></div></div>
                    <button class="btn btn-outline" type="submit">Update password</button>
                    <div class="form-message" role="alert"></div>
                </form>
                ${toggleRow("twoStep", "Two-step verification", "Require a one-time code on new devices", s.twoStep)}
                ${toggleRow("biometric", "Face ID / fingerprint", "Quick sign-in on supported mobile devices", s.biometric)}
            </section>

            <section class="settings-card">
                <h3>Alerts &amp; notifications</h3>
                ${toggleRow("alertTransactions", "Transaction alerts", "Transfers and payments on your account", s.alertTransactions)}
                ${toggleRow("alertLowBalance", "Low balance alerts", "When checking falls below $100", s.alertLowBalance)}
                ${toggleRow("alertSecurity", "Security alerts", "Password changes and new sign-ins", s.alertSecurity)}
                ${toggleRow("channelEmail", "Email", "Send alerts by email", s.channelEmail)}
                ${toggleRow("channelSms", "Text message", "Send alerts by SMS", s.channelSms)}
                ${toggleRow("channelPush", "Push notifications", "Send alerts to the mobile app", s.channelPush)}
            </section>

            <section class="settings-card">
                <h3>Statements &amp; privacy</h3>
                ${toggleRow("paperless", "Paperless statements", "Receive e-statements and tax documents online", s.paperless)}
                ${toggleRow("marketing", "Offers &amp; promotions", "Allow marketing messages from NexaBank", s.marketing)}
                <div class="settings-links"><a href="#">Privacy policy</a><a href="#">Terms &amp; conditions</a><a href="#">Contact support</a></div>
            </section>
        </div>`;
    }

    function buildPanels() {
        overviewNodes = Array.from(dashboardContent.children);

        panelEl = document.createElement("div");
        panelEl.id = "dashboardPanel";
        panelEl.hidden = true;
        dashboardContent.appendChild(panelEl);

        document.querySelectorAll(".dashboard-nav-item").forEach((button, i) => {
            button.addEventListener("click", () => showPanel(PANEL_ORDER[i] || "overview"));
        });

        logoutBtn.addEventListener("click", () => showPanel("overview"));

        panelEl.addEventListener("change", event => {
            const key = event.target.dataset.setting;
            if (!key || !currentUser) return;

            currentUser.settings = { ...getSettings(), [key]: event.target.checked };
            persistUser(currentUser);
            showToast("Settings saved", "Your preference has been updated.");
        });

        panelEl.addEventListener("submit", async event => {
            event.preventDefault();
            const form = event.target;
            const message = form.querySelector(".form-message");
            clearMessage(message);

            if (form.id === "profileForm") {
                const name = $("setName").value.trim();
                const phone = $("setPhone").value.replace(/\D/g, "");
                const state = $("setState").value.trim().toUpperCase();
                const zip = $("setZip").value.trim();

                if (name.length < 2) return showMessage(message, "Please enter your full name.");
                if (phone && phone.length !== 10) return showMessage(message, "Enter a 10-digit US phone number.");
                if (state && !/^[A-Z]{2}$/.test(state)) return showMessage(message, "Use the 2-letter state code.");
                if (zip && !/^\d{5}(-\d{4})?$/.test(zip)) return showMessage(message, "Enter a valid ZIP code.");

                currentUser.name = name;
                currentUser.settings = {
                    ...getSettings(),
                    profile: { phone, street: $("setStreet").value.trim(), city: $("setCity").value.trim(), state, zip }
                };
                persistUser(currentUser);
                updateDashboard();
                showMessage(message, "Profile updated.", "success");
            }

            if (form.id === "passwordForm") {
                const current = $("curPw").value, next = $("newPw").value;

                if ((await hashPassword(current)) !== currentUser.passwordHash) return showMessage(message, "Current password is incorrect.");
                if (next.length < 8) return showMessage(message, "New password must be at least 8 characters.");
                if (next !== $("newPw2").value) return showMessage(message, "New passwords do not match.");

                currentUser.passwordHash = await hashPassword(next);
                persistUser(currentUser);
                form.reset();
                showMessage(message, "Password updated.", "success");
            }
        });
    }

    function showPanel(name) {
        if (!panelEl) return;

        document.querySelectorAll(".dashboard-nav-item").forEach((item, i) => {
            item.classList.toggle("active", PANEL_ORDER[i] === name);
        });

        const showOverview = name === "overview" || name === "transfers";

        overviewNodes.forEach(node => { node.hidden = !showOverview; });
        panelEl.hidden = showOverview;

        if (name === "cards") {
            panelEl.innerHTML = comingSoonHTML("fa-credit-card", "Cards", "Manage your debit cards, freeze and unfreeze, and set travel notices. We're putting the finishing touches on this.");
        } else if (name === "insights") {
            panelEl.innerHTML = comingSoonHTML("fa-chart-pie", "Insights", "Spending breakdowns, trends and savings tips are on the way.");
        } else if (name === "settings" && currentUser) {
            panelEl.innerHTML = settingsHTML();
        }

        if (name === "transfers") transferForm.scrollIntoView({ behavior: "smooth", block: "center" });
    }


    /* =====================================================
       14. DASHBOARD UI
    ===================================================== */

    dashboardMobileMenu.addEventListener("click", () => {
        dashboardSidebar.classList.toggle("active");
    });

    document.querySelectorAll(".dashboard-nav-item").forEach(button => {
        button.addEventListener("click", () => {
            document
                .querySelectorAll(".dashboard-nav-item")
                .forEach(item => item.classList.remove("active"));

            button.classList.add("active");
            dashboardSidebar.classList.remove("active");
        });
    });

    /* Hide / show balances */
    document.querySelectorAll(".balance-eye").forEach(button => {
        button.addEventListener("click", () => {
            if (!currentUser) return;

            const type = button.dataset.balance === "checking" ? "checking" : "savings";

            hiddenBalances[type] = !hiddenBalances[type];
            renderBalances();
        });
    });

    $("viewAllTransactions").addEventListener("click", () => {
        if (!currentUser) return;

        showToast(
            "Transaction history",
            `Showing your ${currentUser.transactions.length} most recent transactions.`
        );
    });


    /* =====================================================
       15. INIT
    ===================================================== */

    async function init() {
        await ensureDemoAccount();
        buildTransferForm();
        buildPanels();
        restoreSession();
    }

    document.addEventListener("DOMContentLoaded", init);


})();
